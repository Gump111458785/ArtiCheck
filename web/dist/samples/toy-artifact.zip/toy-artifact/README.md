ArtiCheck teaching fixture. Run python3 probe.py. Python standard library only.
